/* MyScreen — mock visuals: fake captured desktop, window thumbnails, app icons.
   All CSS/SVG drawn, no photography. */
(function () {
  const e = React.createElement;

  // colorful rounded app-icon tile with a letter
  function AppIcon({ bg, label, size = 18, radius = 4 }) {
    return e('div', {
      style: {
        width: size, height: size, borderRadius: radius, background: bg, flex: '0 0 auto',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: '#fff', fontSize: size * 0.5, fontWeight: 700,
        boxShadow: 'inset 0 0 0 .5px rgba(255,255,255,.25)',
      },
    }, label);
  }

  // mini fake code window content
  function CodeMini() {
    return e('div', { className: 'fk-code' },
      e('div', null, e('span', { className: 'k' }, 'function '), e('span', { className: 'f' }, 'startRecording'), '() {'),
      e('div', { style: { paddingLeft: 12 } }, e('span', { className: 'k' }, 'const '), 'stream = ', e('span', { className: 'k' }, 'await'), ' getDisplayMedia()'),
      e('div', { style: { paddingLeft: 12 } }, e('span', { className: 'c' }, '// stream to disk')),
      e('div', { style: { paddingLeft: 12 } }, 'recorder.', e('span', { className: 'f' }, 'start'), '(', e('span', { className: 's' }, '250'), ')'),
      e('div', null, '}'),
    );
  }

  // a single fake app window
  function FakeWindow({ title, accent = '#5fb3e0', children, style }) {
    return e('div', { className: 'fk-win', style },
      e('div', { className: 'fk-titlebar' },
        e('i', { style: { background: '#ff5f57' } }),
        e('i', { style: { background: '#febc2e' } }),
        e('i', { style: { background: '#28c840' } }),
        e('span', { style: { fontSize: 8, color: '#9aa3b0', marginLeft: 6 } }, title),
      ),
      children,
    );
  }

  // full desktop scene (Full Screen capture)
  function FakeDesktop() {
    return e('div', { className: 'capture' },
      e('div', { className: 'fk-wall' }),
      e('div', { className: 'fk-menubar' },
        e('span', { style: { fontSize: 8, color: 'rgba(255,255,255,.7)', fontWeight: 700 } }, ''),
        e('div', { style: { flex: 1 } }),
        e('div', { className: 'd' }), e('div', { className: 'd' }), e('div', { className: 'd' }),
      ),
      e(FakeWindow, {
        title: 'editor.js — myscreen', accent: '#5fb3e0',
        style: { left: '6%', top: '14%', width: '52%', height: '70%' },
      }, e(CodeMini)),
      e(FakeWindow, {
        title: 'Preview', accent: '#7ac442',
        style: { right: '6%', top: '26%', width: '34%', height: '52%', background: '#fbfbfb' },
      },
        e('div', { style: { padding: '10px 12px' } },
          e('div', { style: { width: '60%', height: 8, borderRadius: 3, background: '#14aae2', marginBottom: 8 } }),
          e('div', { className: 'fk-bar', style: { width: '90%' } }),
          e('div', { className: 'fk-bar', style: { width: '80%' } }),
          e('div', { className: 'fk-bar', style: { width: '85%' } }),
          e('div', { style: { display: 'flex', gap: 6, marginTop: 10 } },
            e('div', { style: { width: 34, height: 12, borderRadius: 3, background: '#7ac442' } }),
            e('div', { style: { width: 34, height: 12, borderRadius: 3, background: '#ececec' } }),
          ),
        ),
      ),
    );
  }

  // single window capture (one app, framed)
  function FakeWindowCapture({ which }) {
    if (which === 'browser') {
      return e('div', { className: 'capture window-mode' },
        e('div', { className: 'cap-shadow' },
          e('div', { style: { position: 'absolute', inset: 0, background: '#fbfbfb' } },
            e('div', { style: { height: '14%', background: '#ededef', display: 'flex', alignItems: 'center', gap: 6, padding: '0 12px' } },
              e('i', { style: { width: 8, height: 8, borderRadius: '50%', background: '#ff5f57' } }),
              e('i', { style: { width: 8, height: 8, borderRadius: '50%', background: '#febc2e' } }),
              e('i', { style: { width: 8, height: 8, borderRadius: '50%', background: '#28c840' } }),
              e('div', { style: { flex: 1, height: 14, borderRadius: 7, background: '#fff', marginLeft: 8, border: '1px solid #ddd' } }),
            ),
            e('div', { style: { padding: '5% 7%' } },
              e('div', { style: { width: '45%', height: 18, borderRadius: 5, background: '#14aae2', marginBottom: 16 } }),
              e('div', { style: { display: 'flex', gap: 14 } },
                e('div', { style: { flex: 2 } },
                  e('div', { className: 'fk-bar', style: { height: 9, width: '95%' } }),
                  e('div', { className: 'fk-bar', style: { height: 9, width: '88%' } }),
                  e('div', { className: 'fk-bar', style: { height: 9, width: '92%' } }),
                  e('div', { className: 'fk-bar', style: { height: 9, width: '70%' } }),
                ),
                e('div', { style: { flex: 1, background: '#eef7e6', borderRadius: 8, minHeight: 70, border: '1px solid #d8ecc6' } }),
              ),
            ),
          ),
        ),
      );
    }
    return e('div', { className: 'capture window-mode' },
      e('div', { className: 'cap-shadow', style: { background: '#23262e' } }, e(CodeMini)),
    );
  }

  // camera-only big feed
  function CameraScene() {
    return e('div', { className: 'capture', style: { background: 'radial-gradient(60% 70% at 50% 35%, #44525f, #232a33 70%, #1a2028)' } },
      e('div', { style: { position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' } },
        e(window.Icon, { name: 'webcam', size: 86, strokeWidth: 1.2, style: { color: 'rgba(255,255,255,.32)' } }),
      ),
    );
  }

  // person placeholder inside camera overlay
  function CamFace({ mirrored }) {
    return e('div', {
      style: {
        width: '100%', height: '100%', display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
        background: 'radial-gradient(70% 80% at 50% 30%, #5a6b7d, #2a323d 75%)',
        transform: mirrored ? 'scaleX(-1)' : 'none',
      },
    },
      e('svg', { width: '64%', height: '74%', viewBox: '0 0 100 100', style: { display: 'block' } },
        e('circle', { cx: 50, cy: 34, r: 19, fill: 'rgba(255,255,255,.5)' }),
        e('path', { d: 'M14 100 C14 72 30 60 50 60 C70 60 86 72 86 100 Z', fill: 'rgba(255,255,255,.5)' }),
      ),
    );
  }

  window.AppIcon = AppIcon;
  window.FakeDesktop = FakeDesktop;
  window.FakeWindowCapture = FakeWindowCapture;
  window.CameraScene = CameraScene;
  window.CamFace = CamFace;
  window.CodeMini = CodeMini;
})();

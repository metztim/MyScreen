/* MyScreen — primitives + mock data */
(function () {
  const e = React.createElement;
  const { useState, useEffect, useRef } = React;

  function Toggle({ on, onChange }) {
    return e('button', {
      className: 'toggle' + (on ? ' on' : ''), role: 'switch', 'aria-checked': on,
      onClick: (ev) => { ev.stopPropagation(); onChange(!on); },
    });
  }

  // animated mic input meter
  function LevelMeter({ active, bars = 14 }) {
    const [level, setLevel] = useState(0);
    useEffect(() => {
      if (!active) { setLevel(0); return; }
      let raf, t = 0;
      const tick = () => {
        t += 0.18;
        const base = 0.45 + 0.35 * Math.sin(t) + 0.18 * Math.sin(t * 3.3) + (Math.random() - 0.5) * 0.25;
        setLevel(Math.max(0.05, Math.min(1, base)));
        raf = setTimeout(tick, 90);
      };
      tick();
      return () => clearTimeout(raf);
    }, [active]);
    const lit = Math.round(level * bars);
    return e('div', { className: 'meter', 'aria-hidden': true },
      Array.from({ length: bars }).map((_, i) =>
        e('i', {
          key: i,
          className: i < lit ? (i > bars - 4 ? 'hot' : 'lit') : '',
          style: { height: `${4 + (i / bars) * 14}px` },
        })),
    );
  }

  // ── mock data ──────────────────────────────────────────────
  const SCREENS = [
    { id: 's1', kind: 'screen', title: 'Built-in Retina Display', sub: '2560 × 1600', wall: 'linear-gradient(135deg,#2b6f8e,#16303f)' },
    { id: 's2', kind: 'screen', title: 'LG UltraFine', sub: '3840 × 2160 · External', wall: 'linear-gradient(135deg,#3a3050,#1d1830)' },
  ];
  const APPS = [
    { id: 'a1', kind: 'window', app: 'Code', title: 'renderer.js — myscreen', icon: '#3b7fd4', glyph: '{ }', active: true, mini: 'code' },
    { id: 'a2', kind: 'window', app: 'Chrome', title: 'MyScreen — Dashboard', icon: '#e8453c', glyph: 'C', mini: 'browser' },
    { id: 'a3', kind: 'window', app: 'Figma', title: 'Recorder UI / Redesign', icon: '#a259ff', glyph: 'F', mini: 'design' },
    { id: 'a4', kind: 'window', app: 'Slack', title: '#design-review', icon: '#4a154b', glyph: 'S', mini: 'chat' },
    { id: 'a5', kind: 'window', app: 'Notion', title: 'Launch checklist', icon: '#2a2a2a', glyph: 'N', mini: 'doc' },
    { id: 'a6', kind: 'window', app: 'Keynote', title: 'Q3 All-hands', icon: '#1aa3e0', glyph: 'K', mini: 'slide' },
  ];
  const MICS = ['MacBook Pro Microphone', 'Shure MV7 (USB)', 'AirPods Pro'];
  const CAMS = ['FaceTime HD Camera', 'Logitech Brio 4K'];

  const RECORDINGS = [
    { id: 'r1', title: 'Onboarding walkthrough', dur: '4:12', when: 'Today, 9:24 AM', size: '88 MB', src: 'Full Screen', wall: 'linear-gradient(135deg,#2b6f8e,#16303f)', mini: 'code' },
    { id: 'r2', title: 'Bug repro — save dialog', dur: '1:47', when: 'Yesterday', size: '31 MB', src: 'Chrome', wall: 'linear-gradient(135deg,#3a3050,#1d1830)', mini: 'browser' },
    { id: 'r3', title: 'Design review notes', dur: '8:03', when: 'Mon', size: '174 MB', src: 'Figma', wall: 'linear-gradient(135deg,#3d2b4e,#241830)', mini: 'design' },
    { id: 'r4', title: 'Camera intro clip', dur: '0:38', when: 'Mon', size: '12 MB', src: 'Camera', wall: 'radial-gradient(60% 70% at 50% 35%, #44525f, #232a33)', mini: 'cam' },
  ];

  window.Toggle = Toggle;
  window.LevelMeter = LevelMeter;
  window.MS_DATA = { SCREENS, APPS, MICS, CAMS, RECORDINGS };
})();

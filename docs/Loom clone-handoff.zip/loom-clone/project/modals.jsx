/* MyScreen — modals: source picker, permissions, recovery, saving, saved, toast */
(function () {
  const e = React.createElement;
  const { useState, useEffect } = React;
  const Icon = window.Icon;
  const { AppIcon } = window;

  function Thumb({ item }) {
    return e('div', { style: { position: 'absolute', inset: 0 } },
      e('div', { style: { position: 'absolute', inset: 0, background: item.wall || 'linear-gradient(135deg,#2b6f8e,#16303f)' } }),
      item.kind === 'window' || item.app
        ? e('div', { style: { position: 'absolute', inset: '16% 12%', borderRadius: 4, background: '#fbfbfb', boxShadow: '0 6px 16px rgba(0,0,0,.4)', overflow: 'hidden' } },
            e('div', { style: { height: '22%', background: '#e7e7ea', display: 'flex', alignItems: 'center', gap: 3, padding: '0 6px' } },
              e('i', { style: { width: 5, height: 5, borderRadius: '50%', background: '#ff5f57' } }),
              e('i', { style: { width: 5, height: 5, borderRadius: '50%', background: '#febc2e' } }),
              e('i', { style: { width: 5, height: 5, borderRadius: '50%', background: '#28c840' } }),
            ),
            e('div', { style: { padding: 7 } },
              e('div', { style: { width: '50%', height: 5, borderRadius: 2, background: '#14aae2', marginBottom: 5 } }),
              e('div', { style: { width: '90%', height: 4, borderRadius: 2, background: '#dcdadc', marginBottom: 3 } }),
              e('div', { style: { width: '75%', height: 4, borderRadius: 2, background: '#dcdadc' } }),
            ),
          )
        : e('div', { style: { position: 'absolute', left: '6%', top: '12%', right: '6%', bottom: '12%', display: 'flex', gap: '5%' } },
            e('div', { style: { flex: 2, borderRadius: 4, background: 'rgba(0,0,0,.25)' } }),
            e('div', { style: { flex: 1, borderRadius: 4, background: 'rgba(255,255,255,.18)' } }),
          ),
    );
  }

  function Picker({ s, actions }) {
    const D = window.MS_DATA;
    const [q, setQ] = useState('');
    const [sel, setSel] = useState(s.source ? s.source.id : null);
    const screens = D.SCREENS;
    const apps = D.APPS.filter((a) => (a.app + ' ' + a.title).toLowerCase().includes(q.toLowerCase()));
    const all = [...screens, ...apps];
    const chosen = all.find((x) => x.id === sel);

    return e('div', { className: 'scrim', onMouseDown: actions.closePicker },
      e('div', { className: 'sheet', onMouseDown: (ev) => ev.stopPropagation() },
        e('div', { className: 'sheet-head' },
          e('div', null,
            e('div', { className: 'h' }, 'Choose what to record'),
            e('div', { className: 'sub' }, 'Pick a screen or an open app window.'),
          ),
          e('button', { className: 'sheet-x', onClick: actions.closePicker }, e(Icon, { name: 'x', size: 18 })),
        ),
        e('div', { className: 'sheet-body' },
          e('div', { className: 'picker-search' },
            e(Icon, { name: 'search', size: 16, className: 'ic' }),
            e('input', { placeholder: 'Search windows…', value: q, onChange: (ev) => setQ(ev.target.value), autoFocus: true }),
          ),
          e('div', { className: 'pick-group-title' }, 'Screens'),
          e('div', { className: 'pick-grid' },
            screens.map((sc) => e('button', { key: sc.id, className: 'pick-card' + (sel === sc.id ? ' sel' : ''), onClick: () => setSel(sc.id), onDoubleClick: () => actions.confirmPicker(sc) },
              e('div', { className: 'pick-thumb' }, e(Thumb, { item: sc })),
              e('div', { className: 'pick-foot' },
                e(Icon, { name: 'monitor', size: 16, style: { color: 'var(--muted)' } }),
                e('div', { className: 'nm' }, e('div', { className: 't' }, sc.title), e('div', { className: 's' }, sc.sub)),
              ),
            )),
          ),
          e('div', { className: 'pick-group-title' }, 'App windows'),
          apps.length ? e('div', { className: 'pick-grid' },
            apps.map((a) => e('button', { key: a.id, className: 'pick-card' + (sel === a.id ? ' sel' : ''), onClick: () => setSel(a.id), onDoubleClick: () => actions.confirmPicker(a) },
              e('div', { className: 'pick-thumb' }, e(Thumb, { item: a })),
              e('div', { className: 'pick-foot' },
                e(AppIcon, { bg: a.icon, label: a.glyph, size: 18 }),
                e('div', { className: 'nm' }, e('div', { className: 't' }, a.app), e('div', { className: 's' }, a.title)),
                a.active ? e('span', { className: 'pick-badge' }, 'Active') : null,
              ),
            )),
          ) : e('div', { className: 'pick-empty' }, 'No windows match “' + q + '”.'),
        ),
        e('div', { className: 'sheet-foot' },
          e('div', { style: { fontSize: 12.5, color: 'var(--muted)' } }, chosen ? ('Selected: ' + (chosen.app || chosen.title)) : 'Nothing selected'),
          e('div', { className: 'spacer' }),
          e('button', { className: 'btn btn-soft', style: { height: 38 }, onClick: actions.closePicker }, 'Cancel'),
          e('button', { className: 'btn btn-blue', style: { height: 38 }, disabled: !chosen, onClick: () => actions.confirmPicker(chosen) }, 'Select'),
        ),
      ),
    );
  }

  function Permissions({ s, actions }) {
    const P = s.permState;
    const rows = [
      { key: 'screen', icon: 'monitor', t: 'Screen Recording', s: 'So MyScreen can capture your display.' },
      { key: 'cam', icon: 'webcam', t: 'Camera', s: 'For the optional camera overlay.' },
      { key: 'mic', icon: 'mic', t: 'Microphone', s: 'To record your voice.' },
    ];
    const allOk = Object.values(P).every((v) => v === 'ok');
    return e('div', { className: 'scrim' },
      e('div', { className: 'sheet sm' },
        e('div', { className: 'sheet-head' },
          e('div', { style: { width: 40, height: 40, borderRadius: 10, background: 'var(--blue-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--blue)', flex: '0 0 auto' } },
            e(Icon, { name: 'shield', size: 20 })),
          e('div', null,
            e('div', { className: 'h' }, 'Let’s get you set up'),
            e('div', { className: 'sub' }, 'MyScreen needs a few permissions before the first recording.'),
          ),
        ),
        e('div', { className: 'sheet-body' },
          e('div', { className: 'perm-list' },
            rows.map((r) => {
              const ok = P[r.key] === 'ok';
              return e('div', { key: r.key, className: 'perm ' + (ok ? 'ok' : 'todo') },
                e('div', { className: 'pic' }, e(Icon, { name: ok ? 'check' : r.icon, size: 20 })),
                e('div', { className: 'ptx' }, e('div', { className: 't' }, r.t), e('div', { className: 's' }, ok ? 'Granted' : r.s)),
                ok
                  ? e('span', { className: 'status' }, e(Icon, { name: 'check', size: 14 }), 'Ready')
                  : e('button', { className: 'perm-act', onClick: () => actions.grant(r.key) }, 'Enable'),
              );
            }),
          ),
          !allOk ? e('div', { className: 'banner warn', style: { marginTop: 14 } },
            e(Icon, { name: 'info', size: 16, className: 'ic' }),
            e('div', null, 'macOS may list this app as “Electron.” Enable it, then come back — no restart needed.'),
          ) : null,
        ),
        e('div', { className: 'sheet-foot' },
          e('div', { className: 'spacer' }),
          e('button', { className: 'btn ' + (allOk ? 'btn-blue' : 'btn-soft'), style: { height: 40 }, disabled: !allOk, onClick: actions.finishPermissions },
            allOk ? 'Start recording' : 'Waiting for permissions…'),
        ),
      ),
    );
  }

  function Recovery({ actions }) {
    return e('div', { className: 'scrim' },
      e('div', { className: 'sheet sm' },
        e('div', { className: 'sheet-head' },
          e('div', { style: { width: 40, height: 40, borderRadius: 10, background: 'var(--green-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--green)', flex: '0 0 auto' } },
            e(Icon, { name: 'refresh', size: 20 })),
          e('div', null,
            e('div', { className: 'h' }, 'We found an unsaved recording'),
            e('div', { className: 'sub' }, 'MyScreen closed before this one finished saving. It’s safe.'),
          ),
        ),
        e('div', { className: 'sheet-body' },
          e('div', { style: { display: 'flex', gap: 14, alignItems: 'center', padding: 12, border: '1px solid var(--border)', borderRadius: 10 } },
            e('div', { style: { width: 92, aspectRatio: '16/10', borderRadius: 8, overflow: 'hidden', position: 'relative', flex: '0 0 auto' } }, e(Thumb, { item: { wall: 'linear-gradient(135deg,#2b6f8e,#16303f)' } })),
            e('div', null,
              e('div', { style: { fontSize: 14, fontWeight: 700, color: 'var(--ink)' } }, 'Screen recording'),
              e('div', { style: { fontSize: 12.5, color: 'var(--muted)', marginTop: 3, lineHeight: 1.5 } }, 'Today, 9:18 AM', e('br'), 'About 3 min · ~64 MB'),
            ),
          ),
        ),
        e('div', { className: 'sheet-foot' },
          e('button', { className: 'btn btn-soft', style: { height: 40, color: 'var(--red)' }, onClick: actions.discardRecovery }, 'Discard'),
          e('div', { className: 'spacer' }),
          e('button', { className: 'btn btn-blue', style: { height: 40 }, onClick: actions.recover }, e(Icon, { name: 'download', size: 16 }), 'Recover & save'),
        ),
      ),
    );
  }

  function Saving({ s, actions }) {
    return e('div', { className: 'scrim' },
      e('div', { className: 'sheet sm' },
        e('div', { className: 'sheet-head' },
          e('div', null,
            e('div', { className: 'h' }, 'Saving your recording'),
            e('div', { className: 'sub' }, 'Converting to ' + (s.format === 'mp4' ? 'MP4' : 'WebM') + ' — you can keep this open.'),
          ),
        ),
        e('div', { className: 'sheet-body' },
          e('div', { className: 'save-stage' },
            e('div', { className: 'save-thumb' }, e(Thumb, { item: { wall: 'linear-gradient(135deg,#2b6f8e,#16303f)' } }),
              e('div', { className: 'play' }, e('div', { className: 'pc' }, e(Icon, { name: 'film', size: 20 }))),
            ),
            e('div', { className: 'prog' }, e('div', { className: 'fill', style: { width: s.saveProgress + '%' } })),
            e('div', { className: 'prog-meta' },
              e('span', null, Math.round(s.saveProgress) + '%'),
              e('span', null, s.saveProgress > 96 ? 'Almost done…' : ('About ' + Math.max(1, Math.ceil((100 - s.saveProgress) / 12)) + ' min' + (Math.ceil((100 - s.saveProgress) / 12) > 1 ? 's' : '') + ' remaining')),
            ),
          ),
        ),
        e('div', { className: 'sheet-foot' },
          e('div', { style: { fontSize: 12, color: 'var(--muted)', display: 'flex', alignItems: 'center', gap: 7 } }, e(Icon, { name: 'folder', size: 14 }), s.folder),
          e('div', { className: 'spacer' }),
          e('button', { className: 'btn btn-soft', style: { height: 38 }, onClick: actions.cancelSave }, 'Cancel'),
        ),
      ),
    );
  }

  function Saved({ s, actions }) {
    const [copied, setCopied] = useState(false);
    const url = 'myscreen.app/v/8tQ2-onboarding';
    return e('div', { className: 'scrim' },
      e('div', { className: 'sheet sm', style: { maxWidth: 520 } },
        e('div', { className: 'sheet-head' },
          e('div', { style: { width: 40, height: 40, borderRadius: 10, background: 'var(--green-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--green)', flex: '0 0 auto' } },
            e(Icon, { name: 'check', size: 22, strokeWidth: 2.4 })),
          e('div', null,
            e('div', { className: 'h' }, 'Saved! Nice recording.'),
            e('div', { className: 'sub' }, (s.format === 'mp4' ? 'MP4' : 'WebM') + ' · ' + actions.fmt(s.lastDuration || 0) + ' · saved to ' + s.folder),
          ),
        ),
        e('div', { className: 'sheet-body' },
          e('div', { className: 'save-stage' },
            e('div', { className: 'save-thumb' }, e(Thumb, { item: { wall: 'linear-gradient(135deg,#2b6f8e,#16303f)' } }),
              e('div', { className: 'play' }, e('div', { className: 'pc' }, e(Icon, { name: 'play', size: 20, fill: 'currentColor' }))),
            ),
            e('div', { className: 'saved-name' }, 'MyScreen 2026-06-09 at 9.24.mp4'),
            e('div', { className: 'share-box' },
              e(Icon, { name: 'link', size: 15, style: { color: 'var(--muted)', flex: '0 0 auto' } }),
              e('span', { className: 'url' }, url),
              e('button', { className: 'share-copy' + (copied ? ' done' : ''), onClick: () => { setCopied(true); setTimeout(() => setCopied(false), 1800); } }, copied ? 'Copied!' : 'Copy link'),
            ),
          ),
        ),
        e('div', { className: 'sheet-foot' },
          e('button', { className: 'btn btn-soft', style: { height: 40 }, onClick: actions.reveal }, e(Icon, { name: 'folder', size: 16 }), 'Reveal in Finder'),
          e('div', { className: 'spacer' }),
          e('button', { className: 'btn btn-soft', style: { height: 40 }, onClick: actions.recordAgain }, 'Record again'),
          e('button', { className: 'btn btn-blue', style: { height: 40 }, onClick: actions.doneSaved }, 'Done'),
        ),
      ),
    );
  }

  function Toast({ msg }) {
    if (!msg) return null;
    return e('div', { style: { position: 'absolute', left: '50%', bottom: 96, transform: 'translateX(-50%)', zIndex: 60, background: 'rgba(22,24,30,.95)', color: '#fff', padding: '11px 16px', borderRadius: 10, fontSize: 13, fontWeight: 500, boxShadow: 'var(--sh-pop)', display: 'flex', alignItems: 'center', gap: 9, animation: 'pop .2s ease' } },
      e(Icon, { name: 'info', size: 16, style: { color: 'var(--blue)' } }), msg);
  }

  Object.assign(window, { Picker, Permissions, Recovery, Saving, Saved, Toast });
})();

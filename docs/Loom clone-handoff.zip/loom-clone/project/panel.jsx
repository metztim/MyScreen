/* MyScreen — setup panel (right column) */
(function () {
  const e = React.createElement;
  const Icon = window.Icon;
  const { Toggle, LevelMeter } = window;

  function Sec({ title, action, children }) {
    return e('div', { className: 'sec' },
      e('div', { className: 'sec-head' },
        e('div', { className: 'sec-title' }, title),
        action || null,
      ),
      children,
    );
  }

  function ToggleRow({ icon, title, sub, on, onChange, disabled }) {
    return e('div', { className: 'trow' + (on ? ' on' : '') + (disabled ? ' disabled' : '') },
      e('div', { className: 'ic-wrap' }, e(Icon, { name: icon, size: 18 })),
      e('div', { className: 'tx' },
        e('div', { className: 't' }, title),
        sub ? e('div', { className: 's' }, sub) : null,
      ),
      e(Toggle, { on, onChange: disabled ? () => {} : onChange }),
    );
  }

  function ModeCard({ icon, label, active, onClick }) {
    return e('button', { className: 'mode' + (active ? ' active' : ''), onClick },
      e(Icon, { name: icon, size: 22, strokeWidth: 1.7 }),
      e('div', { className: 'lbl' }, label),
    );
  }

  function Seg({ value, options, onChange }) {
    return e('div', { className: 'seg' },
      options.map((o) => e('button', {
        key: o.v, className: value === o.v ? 'sel' : '', onClick: () => onChange(o.v),
      }, o.label)),
    );
  }

  function SetupPanel({ s, set, actions }) {
    const D = window.MS_DATA;
    const camActive = s.camOn && s.mode !== 'camera';

    return e('div', { className: 'panel-scroll' + (s.flow === 'recording' || s.flow === 'paused' ? ' dim-setup' : '') },
      // ── Source ──
      e(Sec, { title: 'Record' },
        e('div', { className: 'modes' },
          e(ModeCard, { icon: 'monitor', label: 'Full screen', active: s.mode === 'screen', onClick: () => actions.setMode('screen') }),
          e(ModeCard, { icon: 'appwindow', label: 'App window', active: s.mode === 'window', onClick: () => actions.setMode('window') }),
          e(ModeCard, { icon: 'webcam', label: 'Camera only', active: s.mode === 'camera', onClick: () => actions.setMode('camera') }),
        ),
        s.mode !== 'camera' && s.source
          ? e('div', { className: 'src-row', onClick: actions.openPicker },
              e('div', { className: 'src-thumb' },
                e('div', { style: { position: 'absolute', inset: 0, background: s.source.wall || 'linear-gradient(135deg,#2b6f8e,#16303f)' } }),
                s.mode === 'window' ? e('div', { style: { position: 'absolute', inset: '18% 14%', borderRadius: 3, background: 'rgba(255,255,255,.9)' } }) : null,
              ),
              e('div', { className: 'src-meta' },
                e('div', { className: 't' }, s.mode === 'window' ? s.source.app : s.source.title),
                e('div', { className: 's' }, s.mode === 'window' ? s.source.title : s.source.sub),
              ),
              e(Icon, { name: 'chevright', size: 16, className: 'chev' }),
            )
          : null,
      ),

      // ── Camera ──
      e(Sec, {
        title: 'Camera',
        action: camActive ? e('button', { className: 'sec-edit', onClick: actions.editOverlay }, e(Icon, { name: 'maximize', size: 13 }), 'Position') : null,
      },
        e(ToggleRow, {
          icon: 'webcam', title: 'Camera overlay',
          sub: s.camOn ? s.camDevice : 'Off',
          on: s.camOn, onChange: (v) => set({ camOn: v }),
          disabled: s.mode === 'camera',
        }),
        s.mode === 'camera' ? e('div', { className: 'nested' }, e('div', { className: 'field-note' }, 'Camera is the recording source in this mode.')) : null,
        camActive ? e('div', { className: 'nested' },
          e('select', { className: 'select', value: s.camDevice, onChange: (ev) => set({ camDevice: ev.target.value }) },
            D.CAMS.map((c) => e('option', { key: c, value: c }, c))),
          e('div', { style: { display: 'flex', gap: 8 } },
            e('div', { style: { flex: 1 } },
              e('div', { className: 'field-lbl' }, 'Shape'),
              e(Seg, { value: s.camShape, onChange: (v) => set({ camShape: v }), options: [{ v: 'rounded', label: 'Rounded' }, { v: 'circle', label: 'Circle' }] }),
            ),
          ),
          e('div', { className: 'trow', style: { padding: 0 } },
            e('div', { className: 'tx' }, e('div', { className: 't', style: { fontSize: 13 } }, 'Mirror camera'), e('div', { className: 's' }, 'Flip horizontally')),
            e(Toggle, { on: s.camMirror, onChange: (v) => set({ camMirror: v }) }),
          ),
        ) : null,
      ),

      // ── Microphone ──
      e(Sec, { title: 'Microphone' },
        e(ToggleRow, {
          icon: s.micOn ? 'mic' : 'micoff', title: 'Microphone',
          sub: s.micOn ? s.micDevice : 'Muted',
          on: s.micOn, onChange: (v) => set({ micOn: v }),
        }),
        s.micOn ? e('div', { className: 'nested' },
          e('select', { className: 'select', value: s.micDevice, onChange: (ev) => set({ micDevice: ev.target.value }) },
            D.MICS.map((m) => e('option', { key: m, value: m }, m))),
          e(LevelMeter, { active: s.micOn }),
        ) : null,
      ),

      // ── System audio (disabled w/ reason) ──
      e(Sec, { title: 'System audio' },
        e(ToggleRow, {
          icon: 'volume', title: 'Capture system sound',
          sub: 'Not available on this Mac', on: s.sysAudioOn, onChange: () => {}, disabled: true,
        }),
        e('div', { className: 'banner warn', style: { marginTop: 2 } },
          e(Icon, { name: 'info', size: 16, className: 'ic' }),
          e('div', null, 'System audio needs an extra macOS helper. ',
            e('button', { className: 'act', onClick: () => actions.toast && actions.toast() }, 'Learn how'),
          ),
        ),
      ),

      // ── Output ──
      e(Sec, { title: 'Output' },
        e('div', null,
          e('div', { className: 'field-lbl' }, 'Format'),
          e(Seg, { value: s.format, onChange: (v) => set({ format: v }), options: [{ v: 'mp4', label: 'MP4' }, { v: 'webm', label: 'WebM' }] }),
        ),
        e('div', null,
          e('div', { className: 'field-lbl' }, 'Quality'),
          e(Seg, {
            value: s.quality, onChange: (v) => set({ quality: v }),
            options: [{ v: 'fast', label: 'Fast' }, { v: 'balanced', label: 'Balanced' }, { v: 'small', label: 'Smaller' }],
          }),
          e('div', { className: 'field-note', style: { marginTop: 6 } },
            s.quality === 'fast' ? 'Quickest to save · larger file.' :
            s.quality === 'small' ? 'Slower to save · smallest file.' :
            'Recommended — good quality, reasonable size.'),
        ),
        e('div', null,
          e('div', { className: 'field-lbl' }, 'Save to'),
          e('div', { className: 'folder' },
            e(Icon, { name: 'folder', size: 16, className: 'ic' }),
            e('span', { className: 'path' }, s.folder),
            e('button', { className: 'link-btn', onClick: () => actions.toast && actions.toast() }, 'Change'),
          ),
        ),
        e(ToggleRow, {
          icon: 'clock', title: '3-2-1 countdown', sub: 'Before recording starts',
          on: s.countdownOn, onChange: (v) => set({ countdownOn: v }),
        }),
      ),

      // ── Advanced ──
      e('div', { className: 'adv' },
        e('button', { className: 'adv-toggle' + (s.advancedOpen ? ' open' : ''), onClick: () => set({ advancedOpen: !s.advancedOpen }) },
          e(Icon, { name: 'chevright', size: 13, className: 'chev' }), 'Advanced'),
        s.advancedOpen ? e('div', { className: 'adv-body' },
          e(ToggleRow, { icon: 'cpu', title: 'Hardware encoding', sub: 'Beta · faster H.264 on supported Macs', on: s.hwEncode, onChange: (v) => set({ hwEncode: v }) }),
          e(ToggleRow, { icon: 'maximize', title: 'Floating controls', sub: 'Show a mini control bar while recording', on: s.floatingOn, onChange: (v) => set({ floatingOn: v }) }),
        ) : null,
      ),
    );
  }

  window.SetupPanel = SetupPanel;
})();

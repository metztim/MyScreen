/* MyScreen — recordings library view */
(function () {
  const e = React.createElement;
  const Icon = window.Icon;

  function LibThumb({ rec }) {
    return e('div', { style: { position: 'absolute', inset: 0 } },
      e('div', { style: { position: 'absolute', inset: 0, background: rec.wall } }),
      rec.mini === 'cam'
        ? e('div', { style: { position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' } }, e(Icon, { name: 'webcam', size: 30, style: { color: 'rgba(255,255,255,.4)' } }))
        : e('div', { style: { position: 'absolute', inset: '16% 12%', borderRadius: 4, background: '#fbfbfb', boxShadow: '0 8px 18px rgba(0,0,0,.4)', overflow: 'hidden' } },
            e('div', { style: { height: '20%', background: '#e7e7ea' } }),
            e('div', { style: { padding: 8 } },
              e('div', { style: { width: '46%', height: 6, borderRadius: 2, background: '#14aae2', marginBottom: 6 } }),
              e('div', { style: { width: '88%', height: 5, borderRadius: 2, background: '#dcdadc', marginBottom: 4 } }),
              e('div', { style: { width: '70%', height: 5, borderRadius: 2, background: '#dcdadc' } }),
            ),
          ),
    );
  }

  function Library({ actions }) {
    const recs = window.MS_DATA.RECORDINGS;
    return e('div', { className: 'lib' },
      e('div', { className: 'lib-head' },
        e('h2', null, 'Your recordings'),
        e('span', { className: 'count' }, recs.length + ' clips'),
        e('div', { style: { flex: 1 } }),
        e('button', { className: 'btn btn-blue', style: { height: 40 }, onClick: actions.newRecording }, e(Icon, { name: 'plus', size: 17 }), 'New recording'),
      ),
      e('div', { className: 'lib-grid' },
        recs.map((r) => e('div', { key: r.id, className: 'lib-card', onClick: () => actions.toast('Playback is mocked in this prototype.') },
          e('div', { className: 'lib-thumb' },
            e(LibThumb, { rec: r }),
            e('span', { className: 'dur' }, r.dur),
            e('div', { className: 'pl' }, e('div', { className: 'pc' }, e(Icon, { name: 'play', size: 18, fill: 'currentColor' }))),
          ),
          e('div', { className: 'lib-info' },
            e('div', { className: 't' }, r.title),
            e('div', { className: 's' }, r.when, e('span', { style: { color: 'var(--faint)' } }, '·'), r.size, e('span', { style: { color: 'var(--faint)' } }, '·'), r.src),
          ),
        )),
      ),
    );
  }

  window.Library = Library;
})();

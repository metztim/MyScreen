/* MyScreen v2 — root app: state machine, chrome, transport, navigator.
   v2: fit-to-viewport scaler, no in-app scrollbars, decluttered stage. */
(function () {
  const e = React.createElement;
  const { useState, useEffect, useRef } = React;
  const Icon = window.Icon;
  const D = window.MS_DATA;

  const INITIAL = {
    view: 'recorder',           // recorder | library
    flow: 'ready',              // ready|picker|overlayEdit|countdown|recording|paused|stopping|saving|saved|permissions|recovery
    mode: 'screen',             // screen|window|camera
    screenSource: D.SCREENS[0],
    windowSource: D.APPS[0],
    camOn: true, camDevice: D.CAMS[0], camMirror: true, camShape: 'rounded',
    camX: 70, camY: 64, camW: 0.2,
    micOn: true, micDevice: D.MICS[0],
    sysAudioOn: false,
    format: 'mp4', quality: 'balanced',
    shareLink: true,
    folder: '~/Movies/MyScreen',
    countdownOn: true,
    advancedOpen: false, hwEncode: false, floatingOn: true,
    countdownN: 3,
    elapsed: 0, lastDuration: 0,
    saveProgress: 0,
    permState: { screen: 'ok', cam: 'ok', mic: 'ok' },
    toastMsg: '',
  };

  function fmt(sec) {
    sec = Math.max(0, Math.floor(sec));
    const m = Math.floor(sec / 60), s = sec % 60;
    return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
  }

  // scale the fixed 1140×740 window down to fit the viewport — the app itself never scrolls
  function useScale() {
    const [sc, setSc] = useState(1);
    useEffect(() => {
      function fit() {
        const w = window.innerWidth - 32, h = window.innerHeight - 32;
        setSc(Math.min(1, w / 1140, h / 740));
      }
      fit();
      window.addEventListener('resize', fit);
      return () => window.removeEventListener('resize', fit);
    }, []);
    return sc;
  }

  function App() {
    const [s, setS] = useState(INITIAL);
    const set = (patch) => setS((p) => ({ ...p, ...patch }));
    const sRef = useRef(s); sRef.current = s;
    const [protoOpen, setProtoOpen] = useState(false);
    const timer = useRef(null), prog = useRef(null), cd = useRef(null);
    const toastT = useRef(null);

    function clearTimers() {
      [timer, prog, cd].forEach((r) => { if (r.current) { clearInterval(r.current); r.current = null; } });
    }
    useEffect(() => () => clearTimers(), []);
    useEffect(() => { window.__ms = { set, get: () => sRef.current }; });

    function toast(msg) {
      set({ toastMsg: msg || 'This is a prototype — that action is mocked.' });
      clearTimeout(toastT.current);
      toastT.current = setTimeout(() => set({ toastMsg: '' }), 2600);
    }

    // ── flow control ─────────────────────────────────────────
    function setMode(m) {
      if (m === 'window' && !sRef.current.windowSource) { set({ mode: m, flow: 'picker' }); return; }
      set({ mode: m });
    }
    const source = s.mode === 'screen' ? s.screenSource : s.mode === 'window' ? s.windowSource : null;

    function openPicker() { set({ flow: 'picker' }); }
    function closePicker() { set({ flow: 'ready' }); }
    function confirmPicker(item) {
      if (!item) return;
      if (item.kind === 'screen') set({ screenSource: item, mode: 'screen', flow: 'ready' });
      else set({ windowSource: item, mode: 'window', flow: 'ready' });
    }
    function editOverlay() { set({ flow: 'overlayEdit' }); }
    function setFlow(f) { set({ flow: f }); }

    function startRecording() {
      clearTimers();
      if (sRef.current.countdownOn) {
        set({ flow: 'countdown', countdownN: 3 });
        cd.current = setInterval(() => {
          const n = sRef.current.countdownN - 1;
          if (n <= 0) { clearInterval(cd.current); cd.current = null; beginRecording(); }
          else set({ countdownN: n });
        }, 850);
      } else beginRecording();
    }
    function beginRecording() {
      set({ flow: 'recording', elapsed: 0 });
      timer.current = setInterval(() => set({ elapsed: sRef.current.elapsed + 1 }), 1000);
    }
    function togglePause() {
      if (sRef.current.flow === 'recording') {
        clearInterval(timer.current); timer.current = null; set({ flow: 'paused' });
      } else if (sRef.current.flow === 'paused') {
        set({ flow: 'recording' });
        timer.current = setInterval(() => set({ elapsed: sRef.current.elapsed + 1 }), 1000);
      }
    }
    function stop() {
      clearTimers();
      set({ flow: 'stopping' });
      setTimeout(() => {
        set({ flow: 'saving', saveProgress: 0, lastDuration: sRef.current.elapsed });
        prog.current = setInterval(() => {
          const next = sRef.current.saveProgress + Math.random() * 7 + 3;
          if (next >= 100) { clearInterval(prog.current); prog.current = null; set({ saveProgress: 100 }); setTimeout(() => set({ flow: 'saved' }), 400); }
          else set({ saveProgress: next });
        }, 240);
      }, 1300);
    }
    function discardRecording() { clearTimers(); set({ flow: 'ready', elapsed: 0 }); }
    function cancelSave() { clearTimers(); set({ flow: 'ready', elapsed: 0, saveProgress: 0 }); toast('Recording discarded.'); }
    function recordAgain() { set({ flow: 'ready', elapsed: 0, saveProgress: 0 }); }
    function doneSaved() { set({ flow: 'ready', view: 'library', elapsed: 0, saveProgress: 0 }); }
    function newRecording() { set({ view: 'recorder', flow: 'ready', elapsed: 0 }); }

    // permissions / recovery
    function gotoPermissions() { set({ flow: 'permissions', permState: { screen: 'todo', cam: 'todo', mic: 'ok' } }); }
    function grant(k) { set({ permState: { ...sRef.current.permState, [k]: 'ok' } }); }
    function finishPermissions() { set({ flow: 'ready' }); }
    function gotoRecovery() { set({ flow: 'recovery' }); }
    function recover() { set({ flow: 'saving', saveProgress: 35, lastDuration: 184 }); prog.current = setInterval(() => { const n = sRef.current.saveProgress + Math.random() * 8 + 3; if (n >= 100) { clearInterval(prog.current); prog.current = null; set({ saveProgress: 100 }); setTimeout(() => set({ flow: 'saved' }), 400); } else set({ saveProgress: n }); }, 240); }
    function discardRecovery() { set({ flow: 'ready' }); toast('Unsaved recording discarded.'); }

    const actions = {
      setMode, openPicker, closePicker, confirmPicker, editOverlay, setFlow,
      startRecording, togglePause, stop, discardRecording, cancelSave, recordAgain, doneSaved, newRecording,
      gotoPermissions, grant, finishPermissions, gotoRecovery, recover, discardRecovery,
      toast, fmt, reveal: () => toast('Revealed in Finder.'),
    };

    // keyboard: space to start/stop (prototype nicety)
    useEffect(() => {
      function onKey(ev) {
        if (ev.code === 'Space' && (s.flow === 'ready') && s.view === 'recorder' && ev.target.tagName !== 'INPUT') { ev.preventDefault(); startRecording(); }
        else if (ev.code === 'Escape' && s.flow === 'overlayEdit') setFlow('ready');
      }
      window.addEventListener('keydown', onKey);
      return () => window.removeEventListener('keydown', onKey);
    });

    // ── derived transport content ────────────────────────────
    const stateInfo = (() => {
      switch (s.flow) {
        case 'recording': return { led: 'rec', t: 'Recording', sub: (s.mode === 'screen' ? 'Full screen' : s.mode === 'window' ? source.app : 'Camera') + (s.micOn ? ' · mic on' : '') };
        case 'paused': return { led: 'busy', t: 'Paused', sub: 'Recording is paused' };
        case 'stopping': return { led: 'busy', t: 'Finishing up…', sub: 'Writing the final chunk' };
        case 'countdown': return { led: 'busy', t: 'Starting…', sub: 'Get ready' };
        default: {
          const where = s.mode === 'screen' ? source.title : s.mode === 'window' ? source.app : 'your camera';
          const bits = [where];
          if (s.camOn && s.mode !== 'camera') bits.push('camera');
          bits.push(s.micOn ? 'mic' : 'no mic');
          bits.push(s.format === 'mp4' ? 'MP4' : 'WebM');
          if (s.shareLink) bits.push('share link');
          return { led: 'ok', t: 'Ready to record', sub: 'Will capture ' + bits.join(' · ') };
        }
      }
    })();

    const recordingNow = s.flow === 'recording' || s.flow === 'paused';
    const scale = useScale();

    // ── render ───────────────────────────────────────────────
    return e(React.Fragment, null,
      e('div', { className: 'scalewrap', style: { transform: 'scale(' + scale + ')' } },
      e('div', { className: 'win' },
      // titlebar
      e('div', { className: 'titlebar' },
        e('div', { className: 'lights' }, e('span', { className: 'light r' }), e('span', { className: 'light y' }), e('span', { className: 'light g' })),
        e('div', { className: 'brand' }, MarkSVG(), e('span', { className: 'name' }, 'MyScreen')),
        e('div', { className: 'tb-spacer' }),
        e('div', { className: 'tb-nav' },
          e('button', { className: 'tb-btn' + (s.view === 'recorder' ? ' active' : ''), onClick: () => set({ view: 'recorder' }) }, e(Icon, { name: 'webcam', size: 15, className: 'ic' }), 'Record'),
          e('button', { className: 'tb-btn' + (s.view === 'library' ? ' active' : ''), onClick: () => set({ view: 'library' }) }, e(Icon, { name: 'film', size: 15, className: 'ic' }), 'Recordings'),
          e('button', { className: 'tb-btn', onClick: () => toast('Settings (mocked).'), title: 'Settings', style: { padding: '0 8px' } }, e(Icon, { name: 'settings', size: 16, className: 'ic' })),
        ),
      ),

      // body
      s.view === 'library'
        ? e('div', { className: 'body' }, e(window.Library, { actions }))
        : e(React.Fragment, null,
            e('div', { className: 'body' },
              e('div', { className: 'stage-col' },
                e(window.Stage, { s: { ...s, source }, set, actions }),
              ),
              e('div', { className: 'panel-col' },
                e(window.SetupPanel, { s: { ...s, source }, set, actions }),
              ),
            ),
            e(Transport, { s, stateInfo, recordingNow, actions }),
          ),

      // overlays
      s.flow === 'picker' ? e(window.Picker, { s: { ...s, source }, actions }) : null,
      s.flow === 'permissions' ? e(window.Permissions, { s, actions }) : null,
      s.flow === 'recovery' ? e(window.Recovery, { actions }) : null,
      s.flow === 'saving' ? e(window.Saving, { s, actions }) : null,
      s.flow === 'saved' ? e(window.Saved, { s, actions }) : null,
      e(window.Toast, { msg: s.toastMsg }),

      // prototype navigator (floats over the stage)
      !['overlayEdit', 'picker', 'permissions', 'recovery', 'saving', 'saved'].includes(s.flow)
        ? e(Navigator, { s, open: protoOpen, setOpen: setProtoOpen, actions, set })
        : null,
      ), // .win
      ), // .scalewrap
    );
  }

  function Transport({ s, stateInfo, recordingNow, actions }) {
    return e('div', { className: 'transport' },
      e('div', { className: 'state-pill' },
        e('div', { className: 'state-led ' + stateInfo.led }),
        e('div', { className: 'state-tx' }, e('div', { className: 't' }, stateInfo.t), e('div', { className: 's' }, stateInfo.sub)),
      ),
      e('div', { className: 'spacer' }),
      e('div', { className: 'timer ' + (recordingNow ? 'rec' : s.flow === 'stopping' ? '' : 'dim') }, fmt(s.elapsed)),
      recordingNow
        ? e('div', { style: { display: 'flex', gap: 10 } },
            e('button', { className: 'btn-ghost', onClick: actions.togglePause, title: s.flow === 'paused' ? 'Resume' : 'Pause' }, e(Icon, { name: s.flow === 'paused' ? 'play' : 'pause', size: 18, fill: s.flow === 'paused' ? 'currentColor' : 'none' })),
            e('button', { className: 'btn btn-stop', onClick: actions.stop }, e('span', { className: 'sq' }), 'Stop'),
          )
        : s.flow === 'stopping'
          ? e('button', { className: 'btn btn-stop', disabled: true }, 'Finishing…')
          : e('button', { className: 'btn btn-rec', disabled: s.flow === 'countdown', onClick: actions.startRecording }, e('span', { className: 'rec-dot' }), 'Start recording'),
    );
  }

  function MarkSVG() {
    return e('svg', { className: 'mark', viewBox: '0 0 32 32', fill: 'none' },
      e('rect', { x: 2, y: 5, width: 28, height: 22, rx: 6, fill: '#14aae2' }),
      e('circle', { cx: 16, cy: 16, r: 6, fill: '#fff' }),
      e('circle', { cx: 16, cy: 16, r: 2.6, fill: '#e8212d' }),
    );
  }

  function Navigator({ s, open, setOpen, actions, set }) {
    const groups = [
      { g: 'Happy path', items: [
        ['Ready', () => set({ view: 'recorder', flow: 'ready', elapsed: 0 })],
        ['Source picker', actions.openPicker],
        ['Camera overlay edit', actions.editOverlay],
        ['Recording', () => { set({ view: 'recorder', flow: 'recording', elapsed: 42 }); }],
        ['Saving', () => { set({ flow: 'saving', saveProgress: 46, lastDuration: 132 }); }],
        ['Saved', () => set({ flow: 'saved', lastDuration: 132 })],
      ] },
      { g: 'Edge states', items: [
        ['First-launch permissions', actions.gotoPermissions],
        ['Crash recovery', actions.gotoRecovery],
        ['Recordings library', () => set({ view: 'library', flow: 'ready' })],
      ] },
    ];
    return e('div', { className: 'proto' },
      open ? e('div', { className: 'proto-menu' },
        groups.map((grp) => e('div', { key: grp.g },
          e('div', { className: 'pg' }, grp.g),
          grp.items.map(([label, fn]) => e('button', { key: label, onClick: () => { fn(); setOpen(false); } }, label)),
        )),
      ) : null,
      e('button', { className: 'proto-toggle', onClick: () => setOpen(!open) },
        e(Icon, { name: 'list', size: 14 }), 'Prototype states'),
    );
  }

  window.MyScreenApp = App;
})();
